let worker;

document.getElementById("startWorker").addEventListener("click", () => {
    if (window.Worker) {
        if (!worker) {
            worker = new Worker("worker.js");

            worker.postMessage("start");

            worker.onmessage = (event) => {
                document.getElementById("result").innerText = `Sonuç: ${ event.data }`;
            }

            worker.onerror = (error) => {
                console.error(`Worker error: ${error}`);
            }
        }
    } else {
        alert("Tarayıcınız desteklemiyor");
    }

});

document.getElementById("stopWorker").addEventListener("click", () => {
    console.log('worker durduldu');
    worker.terminate();
    worker = null;
});