const heavyComputation = (limit) => {
    let sum = 0;
    for (let i = 0; i <= limit; i++) {
        sum += i;
    }

    return sum;
}

self.onmessage = (event) => {
    console.log(`Worker: Mesaj alındı => ${event.data}`);
    
    if (event.data === "start") {
        a;
        const result = heavyComputation(10000000000);
        postMessage(result);
    }
}