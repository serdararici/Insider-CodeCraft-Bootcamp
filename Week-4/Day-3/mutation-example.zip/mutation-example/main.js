const target = document.getElementById("target");

const observer = new MutationObserver((mutationList) => {
    mutationList.forEach((mutation) => {
        debugger;
        console.log("Mutation Yakalandı!");

        if (mutation.type === "childList") {
            console.log("childList Yakalandı!");
            console.log(mutation);
        }

        if (mutation.type === "attributes") {
            console.log("attributes Yakalandı!");
            console.log(mutation);
        }

        if (mutation.type === "characterData") {
            console.log("characterData Yakalandı!");
            console.log(mutation);
        }
    })
});

const observerConfig = {
    childList: true,
    attributes: true,
    characterData: true,
    subtree: true,
    attributesOldValue: true,
    attributeFilter: ['data-test']
}

observer.observe(target, observerConfig);

const takeRecords = () => {
    const changes = observer.takeRecords();
    console.log("takeRecords");
    console.log(changes);
}

const disconnect = () => {
    const changes = observer.takeRecords();
    observer.disconnect();
    console.log("takeRecords");
    console.log(changes);
}


const addChild = () => {
    debugger;
    const newElement = document.createElement('div');
    newElement.textContent = `New Child ${Date.now()}`;
    newElement.className = 'child';
    target.appendChild(newElement);
}

const changeAttributes = () => {
    debugger;
    // target.classList.toggle('toggleClass');
    target.setAttribute('data-test', 'test');
}

const changeText = () => {
    const firstChild = target.querySelector('.child');
    if (firstChild && firstChild.firstChild) {
        firstChild.firstChild.textContent = `Updated Text ${Date.now()}`;
    }

    takeRecords();
}




